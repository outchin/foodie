<?php $__env->startSection('title',translate('Withdraw Request')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Heading -->
        <div class="page-header">
            <h1 class="page-header-title mr-3 mb-md-0">
                <span class="page-header-icon">
                    <img src="<?php echo e(asset('public/assets/admin/img/withdraw.png')); ?>" class="w--26" alt="">
                </span>
                <span>
                    <?php echo e(translate('messages.store_withdraw_transaction')); ?> <span
                        class="badge badge-soft-dark ml-2" id="itemCount"><?php echo e($withdraw_req->total()); ?></span>
                </span>
            </h1>
        </div>
        <!-- Page Heading -->
        <div class="card mt-2">

            <!-- Header -->
            <div class="card-header py-2 border-0">
                <div class="search--button-wrapper justify-content-end">
                    <form class="search-form">
                        
                        <!-- Search -->
                        <div class="input-group input--group">
                            <input id="datatableSearch" name="search" type="search" value="<?php echo e(request()?->search ?? null); ?>" class="form-control h--40px" placeholder="<?php echo e(translate('ex_:_search_store_name')); ?>" aria-label="<?php echo e(translate('messages.search_here')); ?>">
                            <button type="submit" class="btn btn--secondary h--40px"><i class="tio-search"></i></button>
                        </div>
                        <!-- End Search -->
                    </form>

                    <div class="max-sm-flex-1">
                        <select name="withdraw_status_filter" onchange="status_filter(this.value)"
                                class="custom-select h--40px py-0">
                            <option
                                value="all" <?php echo e(session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'all'?'selected':''); ?>>
                                <?php echo e(translate('messages.all')); ?>

                            </option>
                            <option
                                value="approved" <?php echo e(session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'approved'?'selected':''); ?>>
                                <?php echo e(translate('messages.approved')); ?>

                            </option>
                            <option
                                value="denied" <?php echo e(session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'denied'?'selected':''); ?>>
                                <?php echo e(translate('messages.denied')); ?>

                            </option>
                            <option
                                value="pending" <?php echo e(session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'pending'?'selected':''); ?>>
                                <?php echo e(translate('messages.pending')); ?>

                            </option>

                        </select>
                    </div>
                    <!-- Unfold -->
                    <div class="hs-unfold mr-2">
                        <a class="js-hs-unfold-invoker btn btn-sm btn-white dropdown-toggle min-height-40" href="javascript:;"
                            data-hs-unfold-options='{
                                    "target": "#usersExportDropdown",
                                    "type": "css-animation"
                                }'>
                            <i class="tio-download-to mr-1"></i> <?php echo e(translate('messages.export')); ?>

                        </a>

                        <div id="usersExportDropdown"
                            class="hs-unfold-content dropdown-unfold dropdown-menu dropdown-menu-sm-right">
                            
                            <span class="dropdown-header"><?php echo e(translate('messages.download_options')); ?></span>
                            <a id="export-excel" class="dropdown-item" href="<?php echo e(route('admin.transactions.store.withdraw_export', ['type'=>'excel',request()->getQueryString()])); ?>">
                                <img class="avatar avatar-xss avatar-4by3 mr-2"
                                    src="<?php echo e(asset('public/assets/admin')); ?>/svg/components/excel.svg"
                                    alt="Image Description">
                                <?php echo e(translate('messages.excel')); ?>

                            </a>
                            <a id="export-csv" class="dropdown-item" href="<?php echo e(route('admin.transactions.store.withdraw_export', ['type'=>'csv',request()->getQueryString()])); ?>">
                                <img class="avatar avatar-xss avatar-4by3 mr-2"
                                    src="<?php echo e(asset('public/assets/admin')); ?>/svg/components/placeholder-csv-format.svg"
                                    alt="Image Description">
                                .<?php echo e(translate('messages.csv')); ?>

                            </a>
                            
                        </div>
                    </div>
                    <!-- End Unfold -->
                </div>
                <!-- End Row -->
            </div>
            <!-- End Header -->
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table id="datatable"
                            class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                        <thead class="thead-light">
                        <tr>
                            <th class="border-0"><?php echo e(translate('sl')); ?></th>
                            <th class="border-0"><?php echo e(translate('messages.amount')); ?></th>
                            
                            <th class="border-0"><?php echo e(translate('messages.store')); ?></th>
                            <th class="border-0"><?php echo e(translate('messages.request_time')); ?></th>
                            <th class="border-0"><?php echo e(translate('messages.status')); ?></th>
                            <th class="border-0"><?php echo e(translate('messages.action')); ?></th>
                        </tr>
                        </thead>
                        <tbody id="set-rows">
                        <?php $__currentLoopData = $withdraw_req; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$wr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($k+$withdraw_req->firstItem()); ?></td>
                                <td><?php echo e($wr['amount']); ?></td>
                                
                                <td>
                                    <?php if($wr->vendor): ?>
                                    <a class="deco-none"
                                        href="<?php echo e(route('admin.store.view',[$wr->vendor['id'],'module_id'=>$wr->vendor->stores[0]->module_id])); ?>"><?php echo e(Str::limit($wr->vendor->stores[0]->name, 20, '...')); ?></a>
                                    <?php else: ?>
                                    <?php echo e(translate('messages.store deleted!')); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(date('Y-m-d '.config('timeformat'),strtotime($wr->created_at))); ?></td>
                                <td>
                                    <?php if($wr->approved==0): ?>
                                        <label class="badge badge-primary"><?php echo e(translate('messages.pending')); ?></label>
                                    <?php elseif($wr->approved==1): ?>
                                        <label class="badge badge-success"><?php echo e(translate('messages.approved')); ?></label>
                                    <?php else: ?>
                                        <label class="badge badge-danger"><?php echo e(translate('messages.denied')); ?></label>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($wr->vendor): ?>
                                    <a href="<?php echo e(route('admin.transactions.store.withdraw_view',[$wr['id'],$wr->vendor['id']])); ?>"
                                        class="btn action-btn btn--warning btn-outline-warning"><i class="tio-visible-outlined"></i>
                                    </a>
                                    <?php else: ?>
                                    <?php echo e(translate('messages.store_deleted')); ?>

                                    <?php endif; ?>
                                    

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php if(count($withdraw_req) !== 0): ?>
            <hr>
            <?php endif; ?>
            <div class="page-area">
                <?php echo $withdraw_req->links(); ?>

            </div>
            <?php if(count($withdraw_req) === 0): ?>
            <div class="empty--data">
                <img src="<?php echo e(asset('/public/assets/admin/svg/illustrations/sorry.svg')); ?>" alt="public">
                <h5>
                    <?php echo e(translate('no_data_found')); ?>

                </h5>
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function status_filter(type) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.transactions.store.status-filter')); ?>',
                data: {
                    withdraw_status_filter: type
                },
                beforeSend: function () {
                    $('#loading').show()
                },
                success: function (data) {
                    console.log(data)
                    location.reload();
                },
                complete: function () {
                    $('#loading').hide()
                }
            });
        }

        $('#search-form').on('submit', function () {
            var formData = new FormData(this);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.transactions.store.withdraw_search')); ?>',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function () {
                    $('#loading').show();
                },
                success: function (data) {
                    $('#set-rows').html(data.view);
                    $('#itemCount').html(data.total);
                    $('.page-area').hide();
                },
                complete: function () {
                    $('#loading').hide();
                },
            });
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/happy9/snow-delivery-admin-panel/resources/views/admin-views/wallet/withdraw.blade.php ENDPATH**/ ?>