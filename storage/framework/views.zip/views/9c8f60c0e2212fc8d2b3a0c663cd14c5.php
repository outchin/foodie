<?php $__env->startSection('title',translate('new_joining_requests')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-header-title"><i class="tio-filter-list"></i> <?php echo e(translate('new_joining_requests')); ?></h1>
            <div class="page-header-select-wrapper">
                <?php if(!isset(auth('admin')->user()->zone_id)): ?>
                <div class="col-sm-auto min--240">
                    <select name="zone_id" class="form-control js-select2-custom"
                            onchange="set_zone_filter('<?php echo e(url()->full()); ?>', this.value)">
                        <option value="all"><?php echo e(translate('messages.All_Zones')); ?></option>
                        <?php $__currentLoopData = \App\Models\Zone::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($z['id']); ?>" <?php echo e(isset($zone) && $zone->id == $z['id']?'selected':''); ?>>
                                <?php echo e($z['name']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="js-nav-scroller hs-nav-scroller-horizontal mt-2">
                        <!-- Nav -->
                        <ul class="nav nav-tabs mb-3 border-0 nav--tabs">
                            <li class="nav-item">
                                <a class="nav-link active" href="<?php echo e(route('admin.users.delivery-man.new')); ?>"   aria-disabled="true"><?php echo e(translate('messages.pending_delivery_man')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('admin.users.delivery-man.deny')); ?>"  aria-disabled="true"><?php echo e(translate('messages.denied_deliveryman')); ?></a>
                            </li>
                        </ul>
                        <!-- End Nav -->
                    </div>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <!-- Card -->
        <div class="card">
            <!-- Header -->
            <div class="card-header py-2 border-0">
                <div class="search--button-wrapper">
                    <h5 class="card-title">
                        <?php echo e(translate('messages.deliveryman_list')); ?> <span class="badge badge-soft-dark ml-2" id="itemCount"><?php echo e($delivery_men->total()); ?></span>
                    </h5>
                    <form action="javascript:" id="search-form" class="search-form">
                        <!-- Search -->
                            <?php echo csrf_field(); ?>
                            <div class="input-group input--group">
                                <input id="datatableSearch_" type="search" id="search" name="search" class="form-control"
                                        placeholder="<?php echo e(translate('ex_: search_delivery_man')); ?>" value="<?php echo e(isset($search_by) ? $search_by : ''); ?>" aria-label="<?php echo e(translate('messages.search')); ?>" required>
                                <button type="submit" class="btn btn--secondary"><i class="tio-search"></i></button>
                            </div>
                        </form>
                </div>
            </div>
            <!-- End Header -->

            <!-- Table -->
            <div class="table-responsive datatable-custom">
                <table id="columnSearchDatatable"
                        class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                        data-hs-datatables-options='{
                            "order": [],
                            "orderCellsTop": true,
                            "paging":false
                        }'>
                    <thead class="thead-light">
                    <tr>
                        <th class="border-0 text-capitalize"><?php echo e(translate('sl')); ?></th>
                        <th class="border-0 text-capitalize"><?php echo e(translate('messages.name')); ?></th>
                        <th class="border-0 text-capitalize"><?php echo e(translate('messages.contact_info')); ?></th>
                        <th class="border-0 text-capitalize"><?php echo e(translate('messages.zone')); ?></th>
                        <th class="border-0 text-capitalize"><?php echo e(translate('messages.total_orders')); ?></th>
                        <th class="border-0 text-capitalize"><?php echo e(translate('messages.availability_status')); ?></th>
                        <th class="border-0 text-center text-capitalize"><?php echo e(translate('messages.action')); ?></th>
                    </tr>
                    </thead>

                    <tbody id="set-rows">
                    <?php $__currentLoopData = $delivery_men; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+$delivery_men->firstItem()); ?></td>
                            <td>
                                <a class="table-rest-info" href="<?php echo e(route('admin.users.delivery-man.preview',[$dm['id']])); ?>">
                                    <img onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                            src="<?php echo e(asset('storage/app/public/delivery-man')); ?>/<?php echo e($dm['image']); ?>" alt="<?php echo e($dm['f_name']); ?> <?php echo e($dm['l_name']); ?>">
                                    <div class="info">
                                        <h5 class="text-hover-primary mb-0"><?php echo e($dm['f_name'].' '.$dm['l_name']); ?></h5>
                                        <span class="d-block text-body">
                                            <span class="rating">
                                            <i class="tio-star"></i> <?php echo e(count($dm->rating)>0?number_format($dm->rating[0]->average, 1, '.', ' '):0); ?>

                                            </span>
                                        </span>
                                    </div>
                                </a>
                            </td>
                            <td>
                                <a class="deco-none" href="tel:<?php echo e($dm['phone']); ?>"><?php echo e($dm['phone']); ?></a>
                            </td>
                            <td>
                                <?php if($dm->zone): ?>
                                <label class="text--title font-medium mb-0"><?php echo e($dm->zone->name); ?></label>
                                <?php else: ?>
                                <label class="text--title font-medium mb-0"><?php echo e(translate('messages.zone_deleted')); ?></label>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="deco-none" href="tel:<?php echo e($dm['phone']); ?>"><?php echo e(count($dm['orders'])); ?></a>
                            </td>
                            <td>
                                <div>
                                    <?php echo e(translate('messages.currently_assigned_orders')); ?> : <?php echo e($dm->current_orders); ?>

                                </div>
                                <div>
                                    <?php echo e(translate('messages.active_status')); ?> :
                                    <?php if($dm->application_status == 'approved'): ?>
                                        <?php if($dm->active): ?>
                                        <strong class="text-capitalize text-primary"><?php echo e(translate('messages.online')); ?></strong>
                                        <?php else: ?>
                                        <strong class="text-capitalize text-secondary"><?php echo e(translate('messages.offline')); ?></strong>
                                        <?php endif; ?>
                                    <?php elseif($dm->application_status == 'denied'): ?>
                                        <strong class="text-capitalize text-danger"><?php echo e(translate('messages.denied')); ?></strong>
                                    <?php else: ?>
                                        <strong class="text-capitalize text-info"><?php echo e(translate('messages.pending')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <?php if($dm->application_status == 'approved'): ?>

                                <?php else: ?>
                                <div class="col-md-12">
                                    <div class="btn--container justify-content-end">
                                        <a class="btn action-btn btn--primary btn-outline-primary" data-toggle="tooltip" data-placement="top"
                                        data-original-title="<?php echo e(translate('messages.approve')); ?>"
                                        onclick="request_alert('<?php echo e(route('admin.users.delivery-man.application',[$dm['id'],'approved'])); ?>','<?php echo e(translate('messages.you_want_to_approve_this_application')); ?>')"
                                            href="javascript:"><i class="tio-done font-weight-bold"></i> </a>
                                        <?php if($dm->application_status !='denied'): ?>
                                        <a class="btn action-btn btn--danger btn-outline-danger " data-toggle="tooltip" data-placement="top"
                                        data-original-title="<?php echo e(translate('messages.deny')); ?>"
                                        onclick="request_alert('<?php echo e(route('admin.users.delivery-man.application',[$dm['id'],'denied'])); ?>','<?php echo e(translate('messages.you_want_to_deny_this_application')); ?>')"
                                            href="javascript:"><i class="tio-clear font-weight-bold"></i></a>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if(count($delivery_men) !== 0): ?>
                <hr>
                <?php endif; ?>
                <div class="page-area">
                    <?php echo $delivery_men->links(); ?>

                </div>
                <?php if(count($delivery_men) === 0): ?>
                <div class="empty--data">
                    <img src="<?php echo e(asset('/public/assets/admin/svg/illustrations/sorry.svg')); ?>" alt="public">
                    <h5>
                        <?php echo e(translate('no_data_found')); ?>

                    </h5>
                </div>
                <?php endif; ?>
            </div>
            <!-- End Table -->
        </div>
        <!-- End Card -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        $(document).on('ready', function () {
            // INITIALIZATION OF DATATABLES
            // =======================================================
            var datatable = $.HSCore.components.HSDatatables.init($('#columnSearchDatatable'));

            $('#column1_search').on('keyup', function () {
                datatable
                    .columns(1)
                    .search(this.value)
                    .draw();
            });

            $('#column2_search').on('keyup', function () {
                datatable
                    .columns(2)
                    .search(this.value)
                    .draw();
            });

            $('#column3_search').on('keyup', function () {
                datatable
                    .columns(3)
                    .search(this.value)
                    .draw();
            });

            $('#column4_search').on('keyup', function () {
                datatable
                    .columns(4)
                    .search(this.value)
                    .draw();
            });


            // INITIALIZATION OF SELECT2
            // =======================================================
            $('.js-select2-custom').each(function () {
                var select2 = $.HSCore.components.HSSelect2.init($(this));
            });
        });
    </script>

    <script>
        function request_alert(url, message) {
            Swal.fire({
                title: '<?php echo e(translate('messages.are_you_sure')); ?>',
                text: message,
                type: 'warning',
                showCancelButton: true,
                cancelButtonColor: 'default',
                confirmButtonColor: '#FC6A57',
                cancelButtonText: '<?php echo e(translate('messages.no')); ?>',
                confirmButtonText: '<?php echo e(translate('messages.yes')); ?>',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    location.href = url;
                }
            })
        }

        $('#search-form').on('submit', function () {
            var formData = new FormData(this);
            set_filter('<?php echo url()->full(); ?>',formData.get('search'),'search_by')
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/happy9/snow-delivery-admin-panel/resources/views/admin-views/delivery-man/new.blade.php ENDPATH**/ ?>