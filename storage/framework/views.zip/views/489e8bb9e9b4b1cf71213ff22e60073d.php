<?php $__env->startSection('title',\App\Models\BusinessSetting::where(['key'=>'business_name'])->first()->value??translate('messages.dashboard')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <?php if(auth('admin')->user()->role_id == 1): ?>
        <?php ($mod = \App\Models\Module::find(Config::get('module.current_module_id'))); ?>
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center py-2">
                <div class="col-sm mb-2 mb-sm-0">
                    <div class="d-flex align-items-center">
                        <img onerror="this.src='<?php echo e(asset('/public/assets/admin/img/parcel.svg')); ?>'" src="<?php echo e(asset('storage/app/public/module')); ?>/<?php echo e($mod->icon); ?>" width="38" alt="img">
                        <div class="w-0 flex-grow pl-2">
                            <h1 class="page-header-title mb-0"><?php echo e(translate($mod->module_name)); ?> <?php echo e(translate('messages.Dashboard')); ?>.</h1>
                            <p class="page-header-text m-0"><?php echo e(translate('Hello, Here You Can Manage Your')); ?> <?php echo e(translate($mod->module_name)); ?> <?php echo e(translate('orders by Zone.')); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-auto min--280">
                    <select name="zone_id" class="form-control js-select2-custom"
                            onchange="fetch_data_zone_wise(this.value)">
                        <option value="all"><?php echo e(translate('messages.All_Zones')); ?></option>
                        <?php $__currentLoopData = \App\Models\Zone::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($zone['id']); ?>" <?php echo e($params['zone_id'] == $zone['id']?'selected':''); ?>>
                                <?php echo e($zone['name']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <!-- End Page Header -->

        <!-- Stats -->
        <div class="card mb-3">
            <div class="card-body pt-0">
                <div class="d-flex flex-wrap align-items-center justify-content-between statistics--title-area">
                    <div class="statistics--title pr-sm-3" id="stat_zone">
                        <?php echo $__env->make('admin-views.partials._zone-change',['data'=>$data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="statistics--select">
                        <select class="custom-select border-0" name="statistics_type" onchange="order_stats_update(this.value)">
                            <option
                                value="overall" <?php echo e($params['statistics_type'] == 'overall'?'selected':''); ?>>
                                <?php echo e(translate('messages.Overall Statistics')); ?>

                            </option>
                            <option
                                value="today" <?php echo e($params['statistics_type'] == 'today'?'selected':''); ?>>
                                <?php echo e(translate("messages.Today's Statistics")); ?>

                            </option>
                        </select>
                    </div>
                </div>
                <div class="row g-2" id="order_stats">
                    <div class="col-sm-6 col-lg-3">
                        <!-- Card -->
                        <a class="resturant-card dashboard--card __dashboard-card card--bg-1" href="<?php echo e(route('admin.parcel.list',['searching_for_deliverymen'])); ?>">
                        <span class="meter">
                                <span style="height:<?php echo e($data['total_orders']>0?($data['searching_for_dm']*100)/$data['total_orders']:0); ?>%"></span>
                        </span>
                        <h4 class="title"><?php echo e($data['searching_for_dm']); ?></h4>
                        <span class="subtitle"><?php echo e(translate('unassigned_orders')); ?></span>
                        <img src="<?php echo e(asset('/public/assets/admin/img/dashboard/1.png')); ?>" alt="img" class="resturant-icon">
                        </a>
                        <!-- End Card -->
                    </div>

                    <div class="col-sm-6 col-lg-3">
                        <!-- Card -->
                        <a class="resturant-card dashboard--card __dashboard-card card--bg-2" href="<?php echo e(route('admin.parcel.orders',['item_on_the_way'])); ?>">
                        <span class="meter">
                                <span style="height:<?php echo e($data['total_orders']>0?($data['picked_up']*100)/$data['total_orders']:0); ?>%"></span>
                        </span>
                        <h4 class="title"><?php echo e($data['picked_up']); ?></h4>
                        <span class="subtitle"><?php echo e(translate('out_for_delivery')); ?></span>
                        <img src="<?php echo e(asset('/public/assets/admin/img/dashboard/4.png')); ?>" alt="img" class="resturant-icon">
                        </a>
                        <!-- End Card -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <!-- Card -->
                        <a class="resturant-card dashboard--card __dashboard-card card--bg-3" href="<?php echo e(route('admin.parcel.orders',['delivered'])); ?>">
                        <span class="meter">
                                <span style="height:<?php echo e($data['total_orders']>0?($data['delivered']*100)/$data['total_orders']:0); ?>%"></span>
                        </span>
                        <h4 class="title"><?php echo e($data['delivered']); ?></h4>
                        <span class="subtitle"><?php echo e(translate('delivered')); ?></span>
                        <img src="<?php echo e(asset('/public/assets/admin/img/dashboard/2.png')); ?>" alt="img" class="resturant-icon">
                        </a>
                        <!-- End Card -->
                    </div>

                    <div class="col-sm-6 col-lg-3">
                        <!-- Card -->
                        <a class="resturant-card dashboard--card __dashboard-card card--bg-4" href="<?php echo e(route('admin.parcel.orders',['failed'])); ?>">
                        <span class="meter">
                                <span style="height:<?php echo e($data['total_orders']>0?($data['refund_requested']*100)/$data['total_orders']:0); ?>%"></span>
                        </span>
                        <h4 class="title"><?php echo e($data['refund_requested']); ?></h4>
                        <span class="subtitle"><?php echo e(translate('Failed Orders')); ?></span>
                        <img src="<?php echo e(asset('/public/assets/admin/img/dashboard/5.png')); ?>" alt="img" class="resturant-icon">
                        </a>
                        <!-- End Card -->
                    </div>
                </div>
            </div>
        </div>
        <!-- End Stats -->


        <div class="row g-2">
            <div class="col-lg-8 col--xl-8">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex flex-wrap justify-content-between align-items-center __gap-12px">
                            <div class="__gross-amount" id="gross_sale">
                                <h6><?php echo e(\App\CentralLogics\Helpers::format_currency(array_sum($total_sell))); ?></h6>
                                <span><?php echo e(translate('messages.Gross Sale')); ?></span>
                            </div>
                            <div class="chart--label __chart-label p-0 move-left-100 ml-auto">
                                <span class="indicator chart-bg-2"></span>
                                <span class="info">
                                    <?php echo e(translate('sale')); ?> (<?php echo e(date("Y")); ?>)
                                </span>
                            </div>
                            <select class="custom-select border-0 text-center w-auto ml-auto" name="commission_overview"
                                    onchange="commission_overview_stats_update(this.value)">
                                    <option
                                    value="this_year" <?php echo e($params['commission_overview'] == 'this_year'?'selected':''); ?>>
                                    <?php echo e(translate('This year')); ?>

                                </option>
                                <option
                                    value="this_month" <?php echo e($params['commission_overview'] == 'this_month'?'selected':''); ?>>
                                    <?php echo e(translate('This month')); ?>

                                </option>
                                <option
                                    value="this_week" <?php echo e($params['commission_overview'] == 'this_week'?'selected':''); ?>>
                                    <?php echo e(translate('This week')); ?>

                                </option>
                            </select>
                        </div>
                        <div id="commission-overview-board">
    
                            <div id="grow-sale-chart"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col--xl-4">
                <!-- Card -->
                <div class="card h-100">
                    <!-- Header -->
                    <div class="card-header border-0">
                        <h5 class="card-header-title">
                            <?php echo e(translate('User Statistics')); ?>

                        </h5>
                        <div id="stat_zone">

                            <?php echo $__env->make('admin-views.partials._zone-change',['data'=>$data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
                        </div>
                        <select class="custom-select border-0 text-center w-auto" name="user_overview"
                                onchange="user_overview_stats_update(this.value)">
                                <option
                                value="this_year" <?php echo e($params['user_overview'] == 'this_year'?'selected':''); ?>>
                                <?php echo e(translate('This year')); ?>

                            </option>
                            <option
                                value="this_month" <?php echo e($params['user_overview'] == 'this_month'?'selected':''); ?>>
                                <?php echo e(translate('This month')); ?>

                            </option>
                            <option
                                value="this_week" <?php echo e($params['user_overview'] == 'this_week'?'selected':''); ?>>
                                <?php echo e(translate('This week')); ?>

                            </option>
                            <option
                                value="overall" <?php echo e($params['user_overview'] == 'overall'?'selected':''); ?>>
                                <?php echo e(translate('messages.Overall')); ?>

                            </option>
                        </select>
                    </div>
                    <!-- End Header -->

                    <!-- Body -->
                    <div class="card-body" id="user-overview-board">
                        <div class="position-relative pie-chart">
                            <div id="dognut-pie"></div>
                            <!-- Total Orders -->
                            <div class="total--orders">
                                <h3 class="text-uppercase mb-xxl-2"><?php echo e($data['customer'] + $data['stores'] + $data['delivery_man']); ?></h3>
                                <span class="text-capitalize"><?php echo e(translate('messages.total_users')); ?></span>
                            </div>
                            <!-- Total Orders -->
                        </div>
                        <div class="d-flex flex-wrap justify-content-center mt-4">
                            <div class="chart--label">
                                <span class="indicator chart-bg-1"></span>
                                <span class="info">
                                    <?php echo e(translate('messages.customer')); ?> <?php echo e($data['customer']); ?>

                                </span>
                            </div>
                            
                            <div class="chart--label">
                                <span class="indicator chart-bg-3"></span>
                                <span class="info">
                                    <?php echo e(translate('messages.delivery_man')); ?> <?php echo e($data['delivery_man']); ?>

                                </span>
                            </div>
                        </div>

                    </div>
                    <!-- End Body -->
                </div>
            </div>

            

            <div class="col-lg-4 col-md-6">
                <!-- Card -->
                <div class="card h-100" id="top-deliveryman-view">
                    <?php echo $__env->make('admin-views.partials._top-deliveryman',['top_deliveryman'=>$data['top_deliveryman']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <!-- End Card -->
            </div>

            <div class="col-lg-4 col-md-6">
                <!-- Card -->
                <div class="card h-100" id="top-customer-view">
                    <?php echo $__env->make('admin-views.partials._top-customer',['top_customers'=>$data['top_customers']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <!-- End Card -->
            </div>

        </div>
        <?php else: ?>
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><?php echo e(translate('messages.welcome')); ?>, <?php echo e(auth('admin')->user()->f_name); ?>.</h1>
                    <p class="page-header-text"><?php echo e(translate('messages.employee_welcome_message')); ?></p>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('public/assets/admin')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo e(asset('public/assets/admin')); ?>/vendor/chart.js.extensions/chartjs-extensions.js"></script>
    <script src="<?php echo e(asset('public/assets/admin')); ?>/vendor/chartjs-plugin-datalabels/dist/chartjs-plugin-datalabels.min.js"></script>

    <!-- Apex Charts -->
    <script src="<?php echo e(asset('/public/assets/admin/js/apex-charts/apexcharts.js')); ?>"></script>
    <!-- Apex Charts -->

<?php $__env->stopPush(); ?>


<?php $__env->startPush('script_2'); ?>

    <!-- Dognut Pie Chart -->
    <script>
        var options = {
            series: [<?php echo e($data['customer']); ?>, <?php echo e($data['delivery_man']); ?>],
            chart: {
                width: 320,
                type: 'donut',
            },
            labels: ['<?php echo e(translate('Customer')); ?>', '<?php echo e(translate('Delivery man')); ?>'],
            dataLabels: {
                enabled: false,
                style: {
                    colors: ['#005555', '#b9e0e0',]
                }
            },
            responsive: [{
                breakpoint: 1650,
                options: {
                    chart: {
                        width: 250
                    },
                }
            }],
            colors: ['#005555','#111'],
            fill: {
                colors: ['#005555','#b9e0e0']
            },
            legend: {
                show: false
            },
        };

        var chart = new ApexCharts(document.querySelector("#dognut-pie"), options);
        chart.render();

    </script>

    <script>
    var options = {
          series: [{
          name: '<?php echo e(translate('Gross Sale')); ?>',
          data: [<?php echo e($total_sell[1]); ?>,<?php echo e($total_sell[2]); ?>,<?php echo e($total_sell[3]); ?>,<?php echo e($total_sell[4]); ?>,<?php echo e($total_sell[5]); ?>,<?php echo e($total_sell[6]); ?>,<?php echo e($total_sell[7]); ?>,<?php echo e($total_sell[8]); ?>,<?php echo e($total_sell[9]); ?>,<?php echo e($total_sell[10]); ?>,<?php echo e($total_sell[11]); ?>,<?php echo e($total_sell[12]); ?>]
        },{
          name: '<?php echo e(translate('Admin Comission')); ?>',
          data: [<?php echo e($commission[1]); ?>,<?php echo e($commission[2]); ?>,<?php echo e($commission[3]); ?>,<?php echo e($commission[4]); ?>,<?php echo e($commission[5]); ?>,<?php echo e($commission[6]); ?>,<?php echo e($commission[7]); ?>,<?php echo e($commission[8]); ?>,<?php echo e($commission[9]); ?>,<?php echo e($commission[10]); ?>,<?php echo e($commission[11]); ?>,<?php echo e($commission[12]); ?>]
        },{
          name: '<?php echo e(translate('Delivery Comission')); ?>',
          data: [<?php echo e($delivery_commission[1]); ?>,<?php echo e($delivery_commission[2]); ?>,<?php echo e($delivery_commission[3]); ?>,<?php echo e($delivery_commission[4]); ?>,<?php echo e($delivery_commission[5]); ?>,<?php echo e($delivery_commission[6]); ?>,<?php echo e($delivery_commission[7]); ?>,<?php echo e($delivery_commission[8]); ?>,<?php echo e($delivery_commission[9]); ?>,<?php echo e($delivery_commission[10]); ?>,<?php echo e($delivery_commission[11]); ?>,<?php echo e($delivery_commission[12]); ?>]
        }],
          chart: {
          height: 350,
          type: 'area',
          toolbar: {
            show:false
        },
            colors: ['#76ffcd','#ff6d6d', '#005555'],
        },
            colors: ['#76ffcd','#ff6d6d', '#005555'],
        dataLabels: {
          enabled: false,
            colors: ['#76ffcd','#ff6d6d', '#005555'],
        },
        stroke: {
          curve: 'smooth',
          width: 2,
            colors: ['#76ffcd','#ff6d6d', '#005555'],
        },
        fill: {
            type: 'gradient',
            colors: ['#76ffcd','#ff6d6d', '#005555'],
        },
        xaxis: {
        //   type: 'datetime',
          categories: ["<?php echo e(translate('Jan')); ?>", "<?php echo e(translate('Feb')); ?>", "<?php echo e(translate('Mar')); ?>", "<?php echo e(translate('Apr')); ?>", "<?php echo e(translate('May')); ?>", "<?php echo e(translate('Jun')); ?>", "<?php echo e(translate('Jul')); ?>", "<?php echo e(translate('Aug')); ?>", "<?php echo e(translate('Sep')); ?>", "<?php echo e(translate('Oct')); ?>", "<?php echo e(translate('Nov')); ?>", "<?php echo e(translate('Dec')); ?>" ]
        },
        tooltip: {
          x: {
            format: 'dd/MM/yy HH:mm'
          },
        },
        };

        var chart = new ApexCharts(document.querySelector("#grow-sale-chart"), options);
        chart.render();
    </script>

    <!-- Dognut Pie Chart -->
    <script>
        // INITIALIZATION OF CHARTJS
        // =======================================================
        Chart.plugins.unregister(ChartDataLabels);

        $('.js-chart').each(function () {
            $.HSCore.components.HSChartJS.init($(this));
        });

        var updatingChart = $.HSCore.components.HSChartJS.init($('#updatingData'));
    </script>

    <script>
        function order_stats_update(type) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.dashboard-stats.order')); ?>',
                data: {
                    statistics_type: type
                },
                beforeSend: function () {
                    $('#loading').show()
                },
                success: function (data) {
                    insert_param('statistics_type',type);
                    $('#order_stats').html(data.view)
                },
                complete: function () {
                    $('#loading').hide()
                }
            });
        }

        function fetch_data_zone_wise(zone_id) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.dashboard-stats.zone')); ?>',
                data: {
                    zone_id: zone_id
                },
                beforeSend: function () {
                    $('#loading').show()
                },
                success: function (data) {
                    insert_param('zone_id', zone_id);
                    $('#order_stats').html(data.order_stats);
                    $('#user-overview-board').html(data.user_overview);
                    $('#monthly-earning-graph').html(data.monthly_graph);
                    $('#popular-restaurants-view').html(data.popular_restaurants);
                    $('#top-deliveryman-view').html(data.top_deliveryman);
                    $('#top-rated-foods-view').html(data.top_rated_foods);
                    $('#top-restaurants-view').html(data.top_restaurants);
                    $('#top-selling-foods-view').html(data.top_selling_foods);
                    $('#stat_zone').html(data.stat_zone);
                },
                complete: function () {
                    $('#loading').hide()
                }
            });
        }

        function user_overview_stats_update(type) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.dashboard-stats.user-overview')); ?>',
                data: {
                    user_overview: type
                },
                beforeSend: function () {
                    $('#loading').show()
                },
                success: function (data) {
                    insert_param('user_overview',type);
                    $('#user-overview-board').html(data.view)
                },
                complete: function () {
                    $('#loading').hide()
                }
            });
        }
        function commission_overview_stats_update(type) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.dashboard-stats.commission-overview')); ?>',
                data: {
                    commission_overview: type
                },
                beforeSend: function () {
                    $('#loading').show()
                },
                success: function (data) {
                    insert_param('commission_overview',type);
                    $('#commission-overview-board').html(data.view)
                    $('#gross_sale').html(data.gross_sale)
                },
                complete: function () {
                    $('#loading').hide()
                }
            });
        }
    </script>

    <script>
        function insert_param(key, value) {
            key = encodeURIComponent(key);
            value = encodeURIComponent(value);
            // kvp looks like ['key1=value1', 'key2=value2', ...]
            var kvp = document.location.search.substr(1).split('&');
            let i = 0;

            for (; i < kvp.length; i++) {
                if (kvp[i].startsWith(key + '=')) {
                    let pair = kvp[i].split('=');
                    pair[1] = value;
                    kvp[i] = pair.join('=');
                    break;
                }
            }
            if (i >= kvp.length) {
                kvp[kvp.length] = [key, value].join('=');
            }
            // can return this or...
            let params = kvp.join('&');
            // change url page with new params
            window.history.pushState('page2', 'Title', '<?php echo e(url()->current()); ?>?' + params);
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/happy9/snow-delivery-admin-panel/resources/views/admin-views/dashboard-parcel.blade.php ENDPATH**/ ?>