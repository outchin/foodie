<?php $__env->startSection('title',\App\Models\BusinessSetting::where(['key'=>'business_name'])->first()->value??translate('messages.dashboard')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <?php if(auth('admin')->user()->role_id == 1): ?>
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center py-2">
                <div class="col-sm mb-2 mb-sm-0">
                    <div class="d-flex align-items-center">
                        <img src="<?php echo e(asset('/public/assets/admin/img/new-img/users.svg')); ?>" alt="img">
                        <div class="w-0 flex-grow pl-3">
                            
                            <h1 class="page-header-title mb-0"><?php echo e(translate('messages.User Overview')); ?></h1>
                            <p class="page-header-text m-0"><?php echo e(translate('Hello,_here_you_can_manage_your_users_by_zone.')); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-auto min--280">
                    <select name="zone_id" class="form-control js-select2-custom"
                           onchange="set_zone_filter('<?php echo e(url()->full()); ?>',this.value)">
                        <option value="all"><?php echo e(translate('messages.All_Zones')); ?></option>
                        <?php $__currentLoopData = \App\Models\Zone::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($zone['id']); ?>" <?php echo e($params['zone_id'] == $zone['id']?'selected':''); ?>>
                                <?php echo e($zone['name']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <!-- End Page Header -->

        <div class="row g-2 pb-4 mb-0">
















            <div class="col-sm-6 col-lg-4">
                <div class="__user-dashboard-card" style="--theme-clr:#006AB4">
                    <div class="__user-dashboard-card-thumbs">
                        <?php ($total_deliveryman = $inactive_deliveryman + $active_deliveryman); ?>
                        <div class="more-icon">
                            +<?php echo e($total_deliveryman >= 4 ? $total_deliveryman - 2 :  $total_deliveryman); ?>

                        </div>
                        <?php $__currentLoopData = $delivery_man; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('storage/app/public/delivery-man')); ?>/<?php echo e($dm['image']); ?>"
                            onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'" alt="new-img">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>
                    <h3 class="title"><?php echo e($total_deliveryman); ?></h3>
                    <h5 class="subtitle text-capitalize"><?php echo e(translate('messages.total_delivery_man')); ?></h5>
                </div>
            </div>



















        </div>































































































































































































































        <h4 class="mb-md-3"><?php echo e(translate('Deliveryman Statistics')); ?></h4>
        <div class="row g-2">
            <div class="col-lg-8">
                <div class="row gap__10">
                    <div class="col-md-4 col-sm-6">
                        <div class="__customer-statistics-card h-100">
                            <div class="title">
                                <img src="<?php echo e(asset('/public/assets/admin/img/new-img/deliveryman/active.svg')); ?>" alt="new-img">
                                <h4><?php echo e($active_deliveryman); ?></h4>
                            </div>
                            <h4 class="subtitle text-capitalize"><?php echo e(translate('messages.active_delivery_man')); ?></h4>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="__customer-statistics-card h-100" style="--clr:#006AB4">
                            <div class="title">
                                <img src="<?php echo e(asset('/public/assets/admin/img/new-img/deliveryman/newly.svg')); ?>" alt="new-img">
                                <h4><?php echo e($newly_joined_deliveryman); ?></h4>
                            </div>
                            <h4 class="subtitle text-capitalize"><?php echo e(translate('messages.newly_joined_delivery_man')); ?></h4>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="__customer-statistics-card h-100" style="--clr:#FF5A54">
                            <div class="title">
                                <img src="<?php echo e(asset('/public/assets/admin/img/new-img/deliveryman/in-active.svg')); ?>" alt="new-img">
                                <h4><?php echo e($inactive_deliveryman); ?></h4>
                            </div>
                            <h4 class="subtitle text-capitalize"><?php echo e(translate('messages.inactive_deliveryman')); ?></h4>
                        </div>
                    </div>
                </div>















            </div>
            <div class="col-lg-4">
                <div class="card h-100" id="top-deliveryman-view">
                    <?php echo $__env->make('admin-views.partials._top-deliveryman',['top_deliveryman'=>$data['top_deliveryman']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        <?php else: ?>
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><?php echo e(translate('messages.welcome')); ?>, <?php echo e(auth('admin')->user()->f_name); ?>.</h1>
                    <p class="page-header-text"><?php echo e(translate('messages.employee_welcome_message')); ?></p>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <!-- Apex Charts -->
    <script src="<?php echo e(asset('/public/assets/admin/js/apex-charts/apexcharts.js')); ?>"></script>
    <!-- Apex Charts -->

    <script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(\App\Models\BusinessSetting::where('key', 'map_api_key')->first()->value); ?>&callback=initialize&libraries=drawing,places&v=3.49"></script>

    <script>
        var map; // Global declaration of the map
        var drawingManager;
        var lastpolygon = null;
        var polygons = [];
        var dmMarkers = [];

        function resetMap(controlDiv) {
            // Set CSS for the control border.
            const controlUI = document.createElement("div");
            controlUI.style.backgroundColor = "#fff";
            controlUI.style.border = "2px solid #fff";
            controlUI.style.borderRadius = "3px";
            controlUI.style.boxShadow = "0 2px 6px rgba(0,0,0,.3)";
            controlUI.style.cursor = "pointer";
            controlUI.style.marginTop = "8px";
            controlUI.style.marginBottom = "22px";
            controlUI.style.textAlign = "center";
            controlUI.title = "Reset map";
            controlDiv.appendChild(controlUI);
            // Set CSS for the control interior.
            const controlText = document.createElement("div");
            controlText.style.color = "rgb(25,25,25)";
            controlText.style.fontFamily = "Roboto,Arial,sans-serif";
            controlText.style.fontSize = "10px";
            controlText.style.lineHeight = "16px";
            controlText.style.paddingLeft = "2px";
            controlText.style.paddingRight = "2px";
            controlText.innerHTML = "X";
            controlUI.appendChild(controlText);
            // Setup the click event listeners: simply set the map to Chicago.
            controlUI.addEventListener("click", () => {
                lastpolygon.setMap(null);
                $('#coordinates').val('');

            });
        }

        function initialize() {
            <?php ($default_location=\App\Models\BusinessSetting::where('key','default_location')->first()); ?>
            <?php ($default_location=$default_location->value?json_decode($default_location->value, true):0); ?>
            var myLatlng = { lat: <?php echo e($default_location?$default_location['lat']:'23.757989'); ?>, lng: <?php echo e($default_location?$default_location['lng']:'90.360587'); ?> };
            var dmbounds = new google.maps.LatLngBounds(null);
            var myOptions = {
                zoom: 13,
                center: myLatlng,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            }
            var deliveryMan = <?php echo json_encode($deliveryMen); ?>;
            map = new google.maps.Map(document.getElementById("map-canvas"), myOptions);

            var infowindow = new google.maps.InfoWindow();

            map.fitBounds(dmbounds);
            for (var i = 0; i < deliveryMan.length; i++) {
                if (deliveryMan[i].lat) {
                    var contentString = "<div style='float:left'><img style='max-height:40px;wide:auto;' src='<?php echo e(asset('storage/app/public/delivery-man')); ?>/"+deliveryMan[i].image+"'></div><div style='float:right; padding: 10px;'><b>"+deliveryMan[i].name+"</b><br/> "+deliveryMan[i].location+"</div>";
                    var point = new google.maps.LatLng(deliveryMan[i].lat, deliveryMan[i].lng);
                    dmbounds.extend(point);
                    map.fitBounds(dmbounds);
                    var marker = new google.maps.Marker({
                        position: point,
                        map: map,
                        title: deliveryMan[i].image,
                        icon: "<?php echo e(asset('public/assets/admin/img/delivery_boy_map.png')); ?>"
                    });
                    dmMarkers[deliveryMan[i].id] = marker;
                    google.maps.event.addListener(marker, 'click', (function(marker, i) {
                        return function() {
                            infowindow.setContent(
                                "<div style='float:left'><img style='max-height:40px;wide:auto;' src='<?php echo e(asset('storage/app/public/delivery-man')); ?>/" +
                                deliveryMan[i].image +
                                "'></div><div style='float:right; padding: 10px;'><b>" + deliveryMan[i]
                                .name + "</b><br/> " + deliveryMan[i].location + "</b><br/> " + 'Assigned Order: ' + deliveryMan[i].assigned_order_count + "</div>"
                                );
                            infowindow.open(map, marker);
                        }
                    })(marker, i));
                }

            };
        }
        $('#search-form').on('submit', function (e) {
            var formData = new FormData(this);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.users.delivery-man.active-search')); ?>',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) {
                    if(data.dm){
                        var id = data.dm.id;
                        map.panTo(dmMarkers[id].getPosition());
                        map.setZoom(20);
                        dmMarkers[id].setAnimation(google.maps.Animation.BOUNCE);
                        window.setTimeout(() => {
                            dmMarkers[id].setAnimation(null);
                        }, 3);
                    }else{
                        toastr.error('Delivery Man not found', {
                            CloseButton: true,
                            ProgressBar: true
                        });
                    }
                },
            });
        });

        function set_all_zones()
        {
            $.get({
                url: '<?php echo e(route('admin.zone.zoneCoordinates')); ?>',
                dataType: 'json',
                success: function (data) {
                    for(var i=0; i<data.length;i++)
                    {
                        polygons.push(new google.maps.Polygon({
                            paths: data[i],
                            strokeColor: "#FF0000",
                            strokeOpacity: 0.8,
                            strokeWeight: 2,
                            fillColor: "#FF0000",
                            fillOpacity: 0.1,
                        }));
                        polygons[i].setMap(map);
                    }

                },
            });
        }
        $(document).on('ready', function(){
            // set_all_zones();
        });


    var options = {
          series: [{
          name: '<?php echo e(translate('New_Customer_Growth')); ?>',
          data: [<?php echo e($last_year_users > 0 ? number_format($user_data[1]/$last_year_users,2) : 0); ?>,
           <?php echo e($user_data[1] > 0 ? number_format($user_data[2]/$user_data[1],2) : 0); ?>,
           <?php echo e($user_data[2] > 0 ? number_format($user_data[3]/$user_data[2],2) : 0); ?>, 
           <?php echo e($user_data[3] > 0 ? number_format($user_data[4]/$user_data[3],2) : 0); ?>, 
           <?php echo e($user_data[4] > 0 ? number_format($user_data[5]/$user_data[4],2) : 0); ?>, 
           <?php echo e($user_data[5] > 0 ? number_format($user_data[6]/$user_data[5],2) : 0); ?>,
           <?php echo e($user_data[6] > 0 ? number_format($user_data[7]/$user_data[6],2) : 0); ?>,
           <?php echo e($user_data[7] > 0 ? number_format($user_data[8]/$user_data[7],2) : 0); ?>,
           <?php echo e($user_data[8] > 0 ? number_format($user_data[9]/$user_data[8],2) : 0); ?>,
           <?php echo e($user_data[9] > 0 ? number_format($user_data[10]/$user_data[9],2) : 0); ?>,
           <?php echo e($user_data[10] > 0 ? number_format($user_data[11]/$user_data[10],2) : 0); ?>,
           <?php echo e($user_data[11] > 0 ? number_format($user_data[12]/$user_data[11],2) : 0); ?>]
        }],
          chart: {
          height: 235,
          type: 'area',
          toolbar: {
            show:false
        }
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          curve: 'straight',
          width: 2,
        },
        colors: ['#107980'],
        fill: {
            type: 'gradient',
            colors: ['#107980'],
        },
        xaxis: {
        //   type: 'datetime',
          categories: ["<?php echo e(translate('Jan')); ?>", "<?php echo e(translate('Feb')); ?>", "<?php echo e(translate('Mar')); ?>", "<?php echo e(translate('Apr')); ?>", "<?php echo e(translate('May')); ?>", "<?php echo e(translate('Jun')); ?>", "<?php echo e(translate('Jul')); ?>", "<?php echo e(translate('Aug')); ?>", "<?php echo e(translate('Sep')); ?>", "<?php echo e(translate('Oct')); ?>", "<?php echo e(translate('Nov')); ?>", "<?php echo e(translate('Dec')); ?>" ]
        },
        tooltip: {
          x: {
            format: 'dd/MM/yy HH:mm'
          },
        },
        };

        var chart = new ApexCharts(document.querySelector("#customer-growth-chart"), options);
        chart.render();




    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/happy9/snow-delivery-admin-panel/resources/views/admin-views/dashboard-users.blade.php ENDPATH**/ ?>