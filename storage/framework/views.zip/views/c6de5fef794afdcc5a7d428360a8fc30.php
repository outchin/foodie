<div class="d-flex flex-row cart--table-scroll">
        <table class="table table-bordered">
            <thead class="text-muted thead-light">
                <tr class="text-center">
                    <th class="border-bottom-0" scope="col"><?php echo e(translate('messages.item')); ?></th>
                    <th class="border-bottom-0" scope="col"><?php echo e(translate('messages.qty')); ?></th>
                    <th class="border-bottom-0" scope="col"><?php echo e(translate('messages.price')); ?></th>
                    <th class="border-bottom-0" scope="col"><?php echo e(translate('messages.delete')); ?></th>
                </tr>
            </thead>
            <tbody>
            <?php
                $subtotal = 0;
                $addon_price = 0;
                $tax = $store? $store->tax: 0;
                $discount = 0;
                $discount_type = 'amount';
                $discount_on_product = 0;
                $variation_price  = 0;
            ?>
            <?php if(session()->has('cart') && count( session()->get('cart')) > 0): ?>
                <?php
                    $cart = session()->get('cart');
                    if(isset($cart['tax']))
                    {
                        $tax = $cart['tax'];
                    }
                    if(isset($cart['discount']))
                    {
                        $discount = $cart['discount'];
                        $discount_type = $cart['discount_type'];
                    }
                ?>
                <?php $__currentLoopData = session()->get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_array($cartItem)): ?>
                    <?php
                    $variation_price += isset($cartItem['variation_price'])?$cartItem['variation_price']:0;
                    $product_subtotal = ($cartItem['price'])*$cartItem['quantity'];
                    $discount_on_product += ($cartItem['discount']*$cartItem['quantity']);
                    $subtotal += $product_subtotal;
                    $addon_price += $cartItem['addon_price'];
                    ?>
                <tr>
                    <td class="media align-items-center cursor-pointer" onclick="quickViewCartItem(<?php echo e($cartItem['id']); ?>, <?php echo e($key); ?>)">
                        <img class="avatar avatar-sm mr-1" src="<?php echo e(asset('storage/app/public/product')); ?>/<?php echo e($cartItem['image']); ?>"
                                onerror="this.src='<?php echo e(asset('public/assets/admin/img/100x100/2.png')); ?>'" alt="<?php echo e($cartItem['name']); ?> image">
                        <div class="media-body">
                            <h5 class="text-hover-primary mb-0"><?php echo e(Str::limit($cartItem['name'], 10)); ?></h5>
                            <small><?php echo e(Str::limit($cartItem['variant'], 20)); ?></small>
                        </div>
                    </td>
                    <td class="text-center middle-align">
                        <input type="number"  data-key="<?php echo e($key); ?>" class="amount--input form-control text-center" value="<?php echo e($cartItem['quantity']); ?>" min="1" max="<?php echo e($cartItem['maximum_cart_quantity']?? '9999999999'); ?>" onkeyup="updateQuantity(event)">
                    </td>
                    <td class="text-center px-0 py-1">
                        <div class="btn">
                            <?php echo e(\App\CentralLogics\Helpers::format_currency($product_subtotal)); ?>

                        </div> <!-- price-wrap .// -->
                    </td>
                    <td class="align-items-center text-center">
                        <a href="javascript:removeFromCart(<?php echo e($key); ?>)" class="btn btn-sm btn-outline-danger"> <i class="tio-delete-outlined"></i></a>
                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php
        if(session()->get('address') && count(session()->get('address'))>0){
            $delivery_fee = session()->get('address')['delivery_fee'];
        }else{
            $delivery_fee = 0;
        }
        $total = $subtotal+$addon_price;
        $discount_amount = ($discount_type=='percent' && $discount>0)?((($total-$discount_on_product) * $discount)/100):$discount;
        $total -= ($discount_amount + $discount_on_product);
        $tax_included = \App\Models\BusinessSetting::where(['key'=>'tax_included'])->first() ?  \App\Models\BusinessSetting::where(['key'=>'tax_included'])->first()->value : 0;
        $total_tax_amount= ($tax > 0)?(($total * $tax)/100):0;
        $total = $total + $delivery_fee;
    ?>
    <div class="box p-3">
        <dl class="row text-sm-right">

            <dt  class="col-sm-6"><?php echo e(translate('messages.addon')); ?>:</dt>
            <dd class="col-sm-6 text-right"><?php echo e(\App\CentralLogics\Helpers::format_currency($addon_price)); ?></dd>

            <dt  class="col-sm-6"><?php echo e(translate('messages.subtotal')); ?>

                <?php if($tax_included ==  1): ?>
                (<?php echo e(translate('messages.TAX_Included')); ?>)
                <?php ($total_tax_amount=0); ?>
                <?php endif; ?>
                :</dt>
            <dd class="col-sm-6 text-right"><?php echo e(\App\CentralLogics\Helpers::format_currency($subtotal+$addon_price)); ?></dd>


            <dt  class="col-sm-6"><?php echo e(translate('messages.discount')); ?> :</dt>
            <dd class="col-sm-6 text-right">- <?php echo e(\App\CentralLogics\Helpers::format_currency(round($discount_on_product,2))); ?></dd>
            <dt class="col-6"><?php echo e(translate('messages.delivery_fee')); ?> :</dt>
            <dd class="col-6 text-right" id="delivery_price">
                <?php echo e(\App\CentralLogics\Helpers::format_currency($delivery_fee, 2)); ?></dd>
                <?php if($tax_included !=  1): ?>

            <dt  class="col-sm-6"><?php echo e(translate('messages.tax')); ?>  : </dt>
            <dd class="col-sm-6 text-right">
                
                <?php echo e(\App\CentralLogics\Helpers::format_currency(round($total_tax_amount,2))); ?></dd>
<?php endif; ?>
            <dt  class="col-6 pr-0">
                <hr class="mt-0">
            </dt>
            <dt  class="col-6 pl-0">
                <hr class="mt-0">
            </dt>
            <dt  class="col-sm-6"><?php echo e(translate('messages.total')); ?>  : </dt>
            <dd class="col-sm-6 text-right">
                <?php echo e(\App\CentralLogics\Helpers::format_currency(round($total+$total_tax_amount, 2))); ?>

            </dd>

        </dl>
        <form action="<?php echo e(route('admin.pos.order')); ?>?store_id=<?php echo e(request('store_id')); ?>" id='order_place' method="post" onkeydown="return event.key != 'Enter';">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="user_id" id="customer_id">
            <div class="pos--payment-options mt-3 mb-3">
                <h5 class="mb-3"><?php echo e(translate('Payment Method')); ?></h5>
                <ul>
                    <?php ($cod=\App\CentralLogics\Helpers::get_business_settings('cash_on_delivery')); ?>
                    <?php if($cod['status']): ?>
                    <li>
                        <label>
                            <input type="radio" name="type" value="cash" hidden checked>
                            <span><?php echo e(translate('Cash On Delivery')); ?></span>
                        </label>
                    </li>
                    <?php endif; ?>
                    <?php ($wallet=\App\CentralLogics\Helpers::get_business_settings('wallet_status')); ?>
                    <?php if($wallet): ?>
                    <li>
                        <label>
                            <input type="radio" name="type" value="wallet" hidden <?php echo e($cod['status']? '':'checked'); ?>>
                            <span><?php echo e(translate('Wallet')); ?></span>
                        </label>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        
        <div class="row button--bottom-fixed g-1 bg-white">
            <div class="col-sm-6">
                <button type="submit" class="btn  btn--primary btn-sm btn-block"><?php echo e(translate('messages.place_order')); ?> </button>
            </div>
            <div class="col-sm-6">
                <a href="#" class="btn btn--reset btn-sm btn-block" onclick="emptyCart()"><?php echo e(translate('Clear Cart')); ?></a>
            </div>
        </div>
        </form>
    </div>

    <div class="modal fade" id="add-discount" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e(translate('messages.update_discount')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.pos.discount')); ?>" method="post" class="row">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-sm-6">
                            <label for=""><?php echo e(translate('messages.discount')); ?></label>
                            <input type="number" class="form-control" name="discount" min="0" id="discount_input" value="<?php echo e($discount); ?>" max="<?php echo e($discount_type=='percent'?100:1000000000); ?>">
                        </div>
                        <div class="form-group col-sm-6">
                            <label for=""><?php echo e(translate('messages.type')); ?></label>
                            <select name="type" class="form-control" id="discount_input_type" onchange="document.getElementById('discount_input').max=(this.value=='percent'?100:1000000000);">
                                <option value="amount" <?php echo e($discount_type=='amount'?'selected':''); ?>><?php echo e(translate('messages.amount')); ?>(<?php echo e(\App\CentralLogics\Helpers::currency_symbol()); ?>)</option>
                                <option value="percent" <?php echo e($discount_type=='percent'?'selected':''); ?>><?php echo e(translate('messages.percent')); ?>(%)</option>
                            </select>
                        </div>
                        <div class="form-group col-sm-12 text-right mb-0">
                            <button class="btn btn-sm btn--primary" type="submit"><?php echo e(translate('messages.submit')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="add-tax" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e(translate('messages.update_tax')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.pos.tax')); ?>" method="POST" class="row" id="order_submit_form">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-12">
                            <label for=""><?php echo e(translate('messages.tax')); ?>(%)</label>
                            <input type="number" class="form-control" name="tax" min="0">
                        </div>

                        <div class="form-group col-sm-12 mb-0 text-right">
                            <button class="btn btn-sm btn--primary" type="submit"><?php echo e(translate('messages.submit')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deliveryAddrModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-light border-bottom py-3">
                    <h5 class="modal-title flex-grow-1 text-center"><?php echo e(translate('delivery_options')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <?php if($store): ?>
                <div class="modal-body">

                    <?php
                        if(session()->has('address')) {
                            $old = session()->get('address');
                        }else {
                            $old = null;
                        }
                    ?>
                    <form id='delivery_address_store'>
                        <?php echo csrf_field(); ?>

                        <div class="row g-2" id="delivery_address">
                            <div class="col-md-6">
                                <label class="input-label"
                                    for=""><?php echo e(translate('messages.contact_person_name')); ?><span
                                                class="input-label-secondary text-danger">*</span></label>
                                <input type="text" class="form-control" name="contact_person_name"
                                    value="<?php echo e($old ? $old['contact_person_name'] : ''); ?>" placeholder="<?php echo e(translate('messages.Ex :')); ?> Jhone">
                            </div>
                            <div class="col-md-6">
                                <label class="input-label"
                                    for=""><?php echo e(translate('Contact Number')); ?><span
                                                class="input-label-secondary text-danger">*</span></label>
                                <input type="tel" class="form-control" name="contact_person_number"
                                    value="<?php echo e($old ? $old['contact_person_number'] : ''); ?>"  placeholder="<?php echo e(translate('messages.Ex :')); ?> +3264124565">
                            </div>
                            <div class="col-md-4">
                                <label class="input-label" for=""><?php echo e(translate('messages.Road')); ?><span
                                                class="input-label-secondary text-danger">*</span></label>
                                <input type="text" class="form-control" name="road" value="<?php echo e($old ? $old['road'] : ''); ?>"  placeholder="<?php echo e(translate('messages.Ex :')); ?> 4th">
                            </div>
                            <div class="col-md-4">
                                <label class="input-label" for=""><?php echo e(translate('messages.House')); ?><span
                                                class="input-label-secondary text-danger">*</span></label>
                                <input type="text" class="form-control" name="house" value="<?php echo e($old ? $old['house'] : ''); ?>" placeholder="<?php echo e(translate('messages.Ex :')); ?> 45/C">
                            </div>
                            <div class="col-md-4">
                                <label class="input-label" for=""><?php echo e(translate('messages.Floor')); ?><span
                                                class="input-label-secondary text-danger">*</span></label>
                                <input type="text" class="form-control" name="floor" value="<?php echo e($old ? $old['floor'] : ''); ?>"  placeholder="<?php echo e(translate('messages.Ex :')); ?> 1A">
                            </div>
                            <div class="col-md-6">
                                <label class="input-label" for=""><?php echo e(translate('messages.longitude')); ?><span
                                                class="input-label-secondary text-danger">*</span></label>
                                <input type="text" class="form-control" id="longitude" name="longitude"
                                    value="<?php echo e($old ? $old['longitude'] : ''); ?>" readonly >
                            </div>
                            <div class="col-md-6">
                                <label class="input-label" for=""><?php echo e(translate('messages.latitude')); ?><span
                                                class="input-label-secondary text-danger">*</span></label>
                                <input type="text" class="form-control" id="latitude" name="latitude"
                                    value="<?php echo e($old ? $old['latitude'] : ''); ?>" readonly>
                            </div>
                            <div class="col-md-12">
                                <label class="input-label" for=""><?php echo e(translate('messages.address')); ?></label>
                                <textarea name="address" class="form-control" cols="30" rows="3" placeholder="<?php echo e(translate('messages.Ex :')); ?> address"><?php echo e($old ? $old['address'] : ''); ?></textarea>
                            </div>
                            <div class="col-12">
                                <div class="d-flex justify-content-between">
                                    <span class="text-primary">
                                        <?php echo e(translate('* pin the address in the map to calculate delivery fee')); ?>

                                    </span>
                                    <div>
                                        <input type="hidden" name="distance" id="distance">
                                        <span><?php echo e(translate('Delivery fee')); ?> :</span>
                                        <input type="hidden" name="delivery_fee" id="delivery_fee" value="<?php echo e($old ? $old['delivery_fee'] : ''); ?>">
                                        <strong><?php echo e($old ? $old['delivery_fee'] : 0); ?> <?php echo e(\App\CentralLogics\Helpers::currency_symbol()); ?></strong>
                                    </div>
                                </div>
                                <input id="pac-input" class="controls rounded initial-8"
                                    title="<?php echo e(translate('messages.search_your_location_here')); ?>" type="text"
                                    placeholder="<?php echo e(translate('messages.search_here')); ?>" />
                                <div class="mb-2 h-200px" id="map"></div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="btn--container justify-content-end">
                                <button class="btn btn-sm btn--primary w-100" type="button" onclick="deliveryAdressStore()">
                                    <?php echo e(translate('Update_Delivery address')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <?php else: ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <center>
                                <h2>
                                    <?php echo e(translate('messages.please_select_a_store_first')); ?>

                                </h2>
                                <button data-dismiss="modal" class="btn btn-primary"><?php echo e(translate('messages.Ok')); ?></button>
                            </center>
                        </div>
                    </div>
                </div>

                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Duplicate of Delivery Information Modal -->
    


    <script>
    var form = document.getElementById('order_place');
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        var customer_id = document.getElementById('customer');
        if(customer_id.value)
        {
            console.log(customer_id.value);
            document.getElementById('customer_id').value = customer_id.value;
        }
        form.submit();
    })
    </script>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/happy9/snow-delivery-admin-panel/resources/views/admin-views/pos/_cart.blade.php ENDPATH**/ ?>