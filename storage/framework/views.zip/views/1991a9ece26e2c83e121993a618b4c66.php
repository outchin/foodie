<?php $__env->startSection('title',translate('messages.Delivery Man Preview')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-header-title text-break">
                <span class="page-header-icon">
                    <img src="<?php echo e(asset('public/assets/admin/img/delivery-man.png')); ?>" class="w--26" alt="">
                </span>
                <span><?php echo e($dm['f_name'].' '.$dm['l_name']); ?></span>
            </h1>
            <div class="row">
                <div class="js-nav-scroller hs-nav-scroller-horizontal mt-2">
                    <!-- Nav -->
                    <ul class="nav nav-tabs nav--tabs border-0">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.users.delivery-man.preview', ['id'=>$dm->id, 'tab'=> 'info'])); ?>"  aria-disabled="true"><?php echo e(translate('messages.info')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="<?php echo e(route('admin.users.delivery-man.preview', ['id'=>$dm->id, 'tab'=> 'transaction'])); ?>"  aria-disabled="true"><?php echo e(translate('messages.transaction')); ?></a>
                        </li>






                    </ul>
                    <!-- End Nav -->
                </div>
            </div>
        </div>
        <!-- End Page Header -->

        <!-- Card -->
        <div class="card mb-3 mb-lg-5 mt-2">
            <div class="card-header py-2 border-0 gap-2">
                <div class="search--button-wrapper">
                    <h4 class="card-title"><?php echo e(translate('messages.order_transactions')); ?></h4>
                    <div class="min--260">
                        <input type="date" class="form-control" placeholder="<?php echo e(translate('mm/dd/yyyy')); ?>" onchange="set_filter('<?php echo e(route('admin.delivery-man.preview',['id'=>$dm->id, 'tab'=> 'transaction'])); ?>',this.value, 'date')" value="<?php echo e($date); ?>">
                    </div>
                </div>


































            </div>
            <!-- Body -->
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table id="datatable"
                        class="table table-borderless table-thead-bordered table-nowrap justify-content-between table-align-middle card-table">
                        <thead class="thead-light">
                            <tr>
                                <th class="border-0"><?php echo e(translate('sl')); ?></th>
                                <th class="border-0"><?php echo e(translate('messages.order_id')); ?></th>
                                <th class="border-0"><?php echo e(translate('messages.delivery_fee_earned')); ?></th>
                                <th class="border-0"><?php echo e(translate('messages.delivery_tips')); ?></th>
                                <th class="border-0"><?php echo e(translate('messages.date')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php ($digital_transaction = \App\Models\OrderTransaction::where('delivery_man_id', $dm->id)
                        ->when($date, function($query)use($date){
                            return $query->whereDate('created_at', $date);
                        })->paginate(25)); ?>
                        <?php $__currentLoopData = $digital_transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($k+$digital_transaction->firstItem()); ?></td>
                                <td><a href="<?php echo e(route((isset($dt->order) && $dt->order->order_type=='parcel')?'admin.parcel.order.details':'admin.order.details',[$dt->order_id,'module_id'=>$dt->order->module_id])); ?>"><?php echo e($dt->order_id); ?></a></td>
                                <td><?php echo e($dt->original_delivery_charge); ?></td>
                                <td><?php echo e($dt->dm_tips); ?></td>
                                <td><?php echo e($dt->created_at->format('Y-m-d')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- End Body -->
            <div class="card-footer">
                <?php echo $digital_transaction->links(); ?>

            </div>
        </div>
        <!-- End Card -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
<script>
    function request_alert(url, message) {
        Swal.fire({
            title: '<?php echo e(translate('Are you sure?')); ?>' ,
            text: message,
            type: 'warning',
            showCancelButton: true,
            cancelButtonColor: 'default',
            confirmButtonColor: '#FC6A57',
            cancelButtonText: '<?php echo e(translate('messages.no')); ?>',
            confirmButtonText: '<?php echo e(translate('messages.yes')); ?>',
            reverseButtons: true
        }).then((result) => {
            if (result.value) {
                location.href = url;
            }
        })
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/happy9/snow-delivery-admin-panel/resources/views/admin-views/delivery-man/view/transaction.blade.php ENDPATH**/ ?>