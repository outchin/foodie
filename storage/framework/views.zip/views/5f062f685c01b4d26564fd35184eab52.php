<?php if(count($combinations[0]) > 0): ?>
    <table class="table table-borderless table--vertical-middle">
        <thead class="thead-light __bg-7">
            <tr>
                <th class="text-center border-0">
                    <span class="control-label m-0"><?php echo e(translate('messages.Variant')); ?></span>
                </th>
                <th class="text-center border-0">
                    <span class="control-label"><?php echo e(translate('messages.Variant Price')); ?></span>
                </th>
                <?php if($stock): ?>
                <th class="text-center border-0">
                    <span class="control-label text-capitalize"><?php echo e(translate('messages.stock')); ?></span>
                </th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $combinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $combination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $str = '';
                foreach ($combination as $key => $item){
                    if($key > 0 ){
                        $str .= '-'.str_replace(' ', '', $item);
                    }
                    else{
                        $str .= str_replace(' ', '', $item);
                    }
                }
            ?>
            <?php if(strlen($str) > 0): ?>
                <tr>
                    <td class="text-center">
                        <label class="control-label m-0"><?php echo e($str); ?></label>
                    </td>
                    <td>
                        <input type="number" name="price_<?php echo e($str); ?>" value="<?php echo e($price); ?>" min="0" step="0.01"
                               class="form-control" required>
                    </td>
                    <?php if($stock): ?>
                        <td><input type="number" name="stock_<?php echo e($str); ?>" value="1" min="0" step="0.01"
                               class="form-control" required></td>
                    <?php endif; ?>

                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <script>
        update_qty();
        function update_qty()
        {
            var total_qty = 0;
            var qty_elements = $('input[name^="stock_"]');
            for(var i=0; i<qty_elements.length; i++)
            {
                total_qty += parseInt(qty_elements.eq(i).val());
            }
            if(qty_elements.length > 0)
            {

                $('input[name="current_stock"]').attr("readonly", true);
                $('input[name="current_stock"]').val('wrfrwf');
            }
            else{
                $('input[name="current_stock"]').attr("readonly", false);
            }
        }
        $('input[name^="stock_"]').on('keyup', function () {
            var total_qty = 0;
            var qty_elements = $('input[name^="stock_"]');
            for(var i=0; i<qty_elements.length; i++)
            {
                total_qty += parseInt(qty_elements.eq(i).val());
            }
            $('input[name="current_stock"]').val(total_qty);
        });

    </script>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/happy9/snow-delivery-admin-panel/resources/views/admin-views/product/partials/_variant-combinations.blade.php ENDPATH**/ ?>