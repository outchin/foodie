<div id="sidebarMain" class="d-none">
    <aside class="js-navbar-vertical-aside navbar navbar-vertical-aside navbar-vertical navbar-vertical-fixed navbar-expand-xl navbar-bordered  ">
        <div class="navbar-vertical-container">
            <div class="navbar-brand-wrapper justify-content-between">
                <!-- Logo -->
                <?php ($store_logo = \App\Models\BusinessSetting::where(['key' => 'logo'])->first()->value); ?>
                <a class="navbar-brand" href="<?php echo e(route('admin.dispatch.dashboard')); ?>" aria-label="Front">
                    <img class="navbar-brand-logo initial--36" onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'" src="<?php echo e(asset('storage/app/public/business/' . $store_logo)); ?>" alt="Logo">
                    <img class="navbar-brand-logo-mini initial--36" onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'" src="<?php echo e(asset('storage/app/public/business/' . $store_logo)); ?>" alt="Logo">
                </a>
                <!-- End Logo -->

                <!-- Navbar Vertical Toggle -->
                <button type="button" class="js-navbar-vertical-aside-toggle-invoker navbar-vertical-aside-toggle btn btn-icon btn-xs btn-ghost-dark">
                    <i class="tio-clear tio-lg"></i>
                </button>
                <!-- End Navbar Vertical Toggle -->

                <div class="navbar-nav-wrap-content-left">
                    <!-- Navbar Vertical Toggle -->
                    <button type="button" class="js-navbar-vertical-aside-toggle-invoker close">
                        <i class="tio-first-page navbar-vertical-aside-toggle-short-align" data-toggle="tooltip"
                        data-placement="right" title="Collapse"></i>
                        <i class="tio-last-page navbar-vertical-aside-toggle-full-align"
                        data-template='<div class="tooltip d-none d-sm-block" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>'></i>
                    </button>
                    <!-- End Navbar Vertical Toggle -->
                </div>

            </div>

            <!-- Content -->
            <div class="navbar-vertical-content bg--005555" id="navbar-vertical-content">
                <form class="sidebar--search-form">
                    <div class="search--form-group">
                        <button type="button" class="btn"><i class="tio-search"></i></button>
                        <input type="text" class="form-control form--control" placeholder="<?php echo e(translate('Search Menu...')); ?>" id="search-sidebar-menu">
                    </div>
                </form>
                <ul class="navbar-nav navbar-nav-lg nav-tabs">
                <!-- Dashboards -->
                <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/dispatch') ? 'show active' : ''); ?>">
                    <a class="js-navbar-vertical-aside-menu-link nav-link" href="<?php echo e(route('admin.dispatch.dashboard')); ?>" title="<?php echo e(translate('messages.dashboard')); ?>">
                        <i class="tio-home-vs-1-outlined nav-icon"></i>
                        <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                            <?php echo e(translate('messages.dashboard')); ?>

                        </span>
                    </a>
                </li>
                <!-- End Dashboards -->
                <!-- Business Section-->
                <li class="nav-item">
                    <small class="nav-subtitle" title="<?php echo e(translate('messages.dispatch_section')); ?>"><?php echo e(translate('messages.dispatch_management')); ?></small>
                    <small class="tio-more-horizontal nav-subtitle-replacer"></small>
                </li>

                <!-- dispatch -->
                <?php if(\App\CentralLogics\Helpers::module_permission_check('order')): ?>
                    <!-- Order dispachment -->
                    <?php ($modules = \App\Models\Module::Active()->get()); ?>
                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($module->module_type != 'parcel'): ?>
                    <?php ($unassigned = \App\Models\Order::whereHas('module', function($query) use($module){
                                        $query->where('module_id', $module->id);
                                    })->SearchingForDeliveryman()->OrderScheduledIn(30)->StoreOrder()->count()); ?>
                    <?php ($ongoing = \App\Models\Order::whereHas('module', function($query) use($module){
                                        $query->where('module_id', $module->id);
                                    })->Ongoing()->OrderScheduledIn(30)->StoreOrder()->count() ); ?>
                    <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is("admin/dispatch/list/{$module->id}*") ? 'active' : ''); ?>">
                        <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:" title="<?php echo e($module->module_name); ?>">
                            <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                <?php echo e($module->module_name); ?>

                                <span class="badge badge-soft-info badge-pill ml-1">
                                    <?php echo e($unassigned + $unassigned); ?>


                                </span>
                            </span>
                        </a>
                        <ul class="js-navbar-vertical-aside-submenu nav nav-sub" style="<?php echo e(Request::is('admin/dispatch*') ? 'display-block' : 'display-none'); ?>">
                            <li class="nav-item <?php echo e(Request::is("admin/dispatch/list/{$module->id}/searching_for_deliverymen") ? 'active' : ''); ?>">
                                <a class="nav-link " href="<?php echo e(route('admin.dispatch.list', [$module->id,'searching_for_deliverymen'])); ?>" title="<?php echo e(translate('messages.unassigned_orders')); ?>">
                                    <span class="tio-circle nav-indicator-icon"></span>
                                    <span class="text-truncate sidebar--badge-container">
                                        <?php echo e(translate('messages.unassigned_orders')); ?>

                                        <span class="badge badge-soft-info badge-pill ml-1">
                                            <?php echo e($unassigned); ?>

                                        </span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item <?php echo e(Request::is("admin/dispatch/list/{$module->id}/on_going") ? 'active' : ''); ?>">
                                <a class="nav-link " href="<?php echo e(route('admin.dispatch.list', [$module->id,'on_going'])); ?>" title="<?php echo e(translate('messages.ongoingOrders')); ?>">
                                    <span class="tio-circle nav-indicator-icon"></span>
                                    <span class="text-truncate sidebar--badge-container">
                                        <?php echo e(translate('messages.ongoingOrders')); ?>

                                        <span class="badge badge-soft-light badge-pill ml-1">
                                            <?php echo e($unassigned); ?>

                                        </span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php else: ?>
                    <?php ($unassigned = \App\Models\Order::whereHas('module', function($query) use($module){
                                        $query->where('module_id', $module->id);
                                    })->SearchingForDeliveryman()->OrderScheduledIn(30)->ParcelOrder()->count()); ?>
                    <?php ($ongoing = \App\Models\Order::whereHas('module', function($query) use($module){
                                        $query->where('module_id', $module->id);
                                    })->Ongoing()->OrderScheduledIn(30)->ParcelOrder()->count() ); ?>
                    <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is("admin/dispatch/parcel/list/{$module->id}*") ? 'active' : ''); ?>">
                        <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:" title="<?php echo e($module->module_name); ?>">
                            <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                <?php echo e($module->module_name); ?>

                                <span class="badge badge-soft-light badge-pill ml-1">
                                    <?php echo e($unassigned + $ongoing); ?>

                                </span>
                            </span>
                        </a>
                        <ul class="js-navbar-vertical-aside-submenu nav nav-sub" style="<?php echo e(Request::is('admin/dispatch*') ? 'display-block' : 'display-none'); ?>">
                            <li class="nav-item <?php echo e(Request::is("admin/dispatch/parcel/list/{$module->id}/searching_for_deliverymen") ? 'active' : ''); ?>">
                                <a class="nav-link " href="<?php echo e(route('admin.dispatch.parcel.list', [$module->id,'searching_for_deliverymen'])); ?>" title="<?php echo e(translate('messages.unassigned_orders')); ?>">
                                    <span class="tio-circle nav-indicator-icon"></span>
                                    <span class="text-truncate sidebar--badge-container">
                                        <?php echo e(translate('messages.unassigned_orders')); ?>

                                        <span class="badge badge-soft-info badge-pill ml-1">
                                            <?php echo e($unassigned); ?>

                                        </span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item <?php echo e(Request::is("admin/dispatch/parcel/list/{$module->id}/on_going") ? 'active' : ''); ?>">
                                <a class="nav-link " href="<?php echo e(route('admin.dispatch.parcel.list', [$module->id,'on_going'])); ?>" title="<?php echo e(translate('messages.ongoingOrders')); ?>">
                                    <span class="tio-circle nav-indicator-icon"></span>
                                    <span class="text-truncate sidebar--badge-container">
                                        <?php echo e(translate('messages.ongoingOrders')); ?>

                                        <span class="badge badge-soft-light badge-pill ml-1">
                                            <?php echo e($ongoing); ?>

                                        </span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- Order dispachment End-->
                <?php endif; ?>
                <!-- End dispatch -->


                <li class="nav-item py-5">

                </li>

                <li class="__sidebar-hs-unfold px-2" id="tourb-9">
                    <div class="hs-unfold w-100">
                        <a class="js-hs-unfold-invoker navbar-dropdown-account-wrapper" href="javascript:;"
                            data-hs-unfold-options='{
                                    "target": "#accountNavbarDropdown",
                                    "type": "css-animation"
                                }'>
                            <div class="cmn--media right-dropdown-icon d-flex align-items-center">
                                <div class="avatar avatar-sm avatar-circle">
                                    <img class="avatar-img"
                                        onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                        src="<?php echo e(asset('storage/app/public/admin')); ?>/<?php echo e(auth('admin')->user()->image); ?>"
                                        alt="Image Description">
                                    <span class="avatar-status avatar-sm-status avatar-status-success"></span>
                                </div>
                                <div class="media-body pl-3">
                                    <span class="card-title h5">
                                        <?php echo e(auth('admin')->user()->f_name); ?>

                                        <?php echo e(auth('admin')->user()->l_name); ?>

                                    </span>
                                    <span class="card-text"><?php echo e(auth('admin')->user()->email); ?></span>
                                </div>
                            </div>
                        </a>

                        <div id="accountNavbarDropdown"
                                class="hs-unfold-content dropdown-unfold dropdown-menu dropdown-menu-right navbar-dropdown-menu navbar-dropdown-account min--240">
                            <div class="dropdown-item-text">
                                <div class="media align-items-center">
                                    <div class="avatar avatar-sm avatar-circle mr-2">
                                        <img class="avatar-img"
                                                onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                                src="<?php echo e(asset('storage/app/public/admin')); ?>/<?php echo e(auth('admin')->user()->image); ?>"
                                                alt="Image Description">
                                    </div>
                                    <div class="media-body">
                                        <span class="card-title h5"><?php echo e(auth('admin')->user()->f_name); ?></span>
                                        <span class="card-text"><?php echo e(auth('admin')->user()->email); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="dropdown-divider"></div>

                            <a class="dropdown-item" href="<?php echo e(route('admin.settings')); ?>">
                                <span class="text-truncate pr-2" title="Settings"><?php echo e(translate('messages.settings')); ?></span>
                            </a>

                            <div class="dropdown-divider"></div>

                            <a class="dropdown-item" href="javascript:" onclick="Swal.fire({
                                title: '<?php echo e(translate("logout_warning_message")); ?>',
                                showDenyButton: true,
                                showCancelButton: true,
                                confirmButtonColor: '#FC6A57',
                                cancelButtonColor: '#363636',
                                confirmButtonText: `<?php echo e(translate('yes')); ?>`,
                                cancelButtonText: '<?php echo e(translate('Don`t_Logout')); ?>',
                                }).then((result) => {
                                if (result.value) {
                                location.href='<?php echo e(route('logout')); ?>';
                                } else{
                                Swal.fire('<?php echo e(translate('messages.canceled')); ?>', '', 'info')
                                }
                                })">
                                <span class="text-truncate pr-2" title="Sign out"><?php echo e(translate('messages.sign_out')); ?></span>
                            </a>
                        </div>
                    </div>
                </li>
                </ul>
            </div>
            <!-- End Content -->
        </div>
    </aside>
</div>

<div id="sidebarCompact" class="d-none">

</div>


<?php $__env->startPush('script_2'); ?>
<script>
    $(window).on('load' , function() {
        if($(".navbar-vertical-content li.active").length) {
            $('.navbar-vertical-content').animate({
                scrollTop: $(".navbar-vertical-content li.active").offset().top - 150
            }, 10);
        }
    });

    var $rows = $('#navbar-vertical-content li');
    $('#search-sidebar-menu').keyup(function() {
        var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();

        $rows.show().filter(function() {
            var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
            return !~text.indexOf(val);
        }).hide();
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/happy9/snow-delivery-admin-panel/resources/views/layouts/admin/partials/_sidebar_dispatch.blade.php ENDPATH**/ ?>