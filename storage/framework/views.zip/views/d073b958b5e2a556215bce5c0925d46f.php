<?php $__env->startSection('title',translate('Delivery Man Preview')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-header-title text-break">
                <span class="page-header-icon">
                    <img src="<?php echo e(asset('public/assets/admin/img/delivery-man.png')); ?>" class="w--26" alt="">
                </span>
                <span><?php echo e(translate('messages.deliveryman_preview')); ?><span class="badge badge-soft-dark ml-2" id="itemCount"><?php echo e($reviews->total()); ?></span></span>
            </h1>
            <div class="row">
                <?php if($dm->application_status == 'approved'): ?>
                <div class="col-md-12">
                    <div class="js-nav-scroller hs-nav-scroller-horizontal mt-2">
                        <!-- Nav -->
                        <ul class="nav nav-tabs mb-3 border-0 nav--tabs">
                            <li class="nav-item">
                                <a class="nav-link active" href="<?php echo e(route('admin.users.delivery-man.preview', ['id'=>$dm->id, 'tab'=> 'info'])); ?>"  aria-disabled="true"><?php echo e(translate('messages.info')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('admin.users.delivery-man.preview', ['id'=>$dm->id, 'tab'=> 'transaction'])); ?>"  aria-disabled="true"><?php echo e(translate('messages.transaction')); ?></a>
                            </li>






                        </ul>
                        <!-- End Nav -->
                    </div>
                </div>
                <?php else: ?>
                <div class="col-md-12">
                    <div class="btn--container justify-content-end">
                        <a class="btn btn--primary text-capitalize font-weight-bold"
                        onclick="request_alert('<?php echo e(route('admin.users.delivery-man.application',[$dm['id'],'approved'])); ?>','<?php echo e(translate('messages.you_want_to_approve_this_application')); ?>')"
                            href="javascript:"><i class="tio-checkmark-circle-outlined font-weight-bold pr-1"></i> <?php echo e(translate('messages.approve')); ?></a>
                        <?php if($dm->application_status !='denied'): ?>
                        <a class="btn btn--danger text-capitalize font-weight-bold"
                        onclick="request_alert('<?php echo e(route('admin.users.delivery-man.application',[$dm['id'],'denied'])); ?>','<?php echo e(translate('messages.you_want_to_deny_this_application')); ?>')"
                            href="javascript:"><i class="tio-clear-circle-outlined font-weight-bold pr-1"></i> <?php echo e(translate('messages.deny')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>

                <?php endif; ?>
            </div>
        </div>
        <!-- End Page Header -->
        <?php if($dm->application_status == 'approved'): ?>
        <div class="row  mb-3 row-3">
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-sm-6 mb-2 col-md-4">
                <div class="resturant-card card--bg-1">
                    <h2 class="title">
                        <?php echo e($dm->total_delivered_orders()->count()); ?>

                    </h2>
                    <h5 class="subtitle">
                        <?php echo e(translate('messages.total_delivered_orders')); ?>

                    </h5>
                    <img class="resturant-icon w--30" src="<?php echo e(asset('public/assets/admin/img/tick.png')); ?>" alt="img">
                </div>
            </div>

            <!-- Collected Cash Card Example -->












            <!-- Total Earning Card Example -->
            <div class="col-sm-6 mb-2 col-md-4">
                <div class="resturant-card bg--1">
                    <h2 class="title">
                        <?php echo e(\App\CentralLogics\Helpers::format_currency($dm->wallet?$dm->wallet->total_earning:0.00)); ?>

                    </h2>
                    <h5 class="subtitle">
                        <?php echo e(translate('messages.total_earning')); ?>

                    </h5>
                    <img class="resturant-icon" src="<?php echo e(asset('/public/assets/admin/img/transactions/pending.png')); ?>" alt="transactions">
                </div>
            </div>

            <!-- Total Earning Card Example -->

                <?php
                $balance = 0;
                if($dm->wallet){
                    $balance = $dm->wallet->total_earning - ($dm->wallet->total_withdrawn + $dm->wallet->pending_withdraw + $dm->wallet->collected_cash );
                }

                ?>






































































        </div>
    </div>
    </div>
    </div>
        <?php endif; ?>

        <!-- Card -->
        <div class="card mb-3">
            <div class="card-header py-2">
                <div class="search--button-wrapper">
                    <h4 class="card-title">
                        <?php echo e($dm['f_name'].' '.$dm['l_name']); ?>


                        (<?php if($dm->zone): ?>
                            <?php echo e($dm->zone->name); ?>

                        <?php else: ?> <?php echo e(translate('messages.zone_deleted')); ?>

                        <?php endif; ?> )
                        <?php if($dm->application_status=='approved'): ?>
                            <?php if($dm['status']): ?>
                                <?php if($dm['active']): ?>
                                    <label class="badge badge-soft-primary"><?php echo e(translate('messages.online')); ?></label>
                                <?php else: ?>
                                    <label class="badge badge-soft-danger"><?php echo e(translate('messages.offline')); ?></label>
                                <?php endif; ?>
                            <?php else: ?>
                            <span class="badge badge-danger"><?php echo e(translate('messages.suspended')); ?></span>
                            <?php endif; ?>

                        <?php else: ?>
                        <label class="badge badge-soft-<?php echo e($dm->application_status=='pending'?'info':'danger'); ?>"><?php echo e(translate('messages.'.$dm->application_status)); ?></label>
                        <?php endif; ?>
                    </h4>
                    <?php if($dm->application_status=='approved'): ?>
                    <a  href="javascript:"  onclick="request_alert('<?php echo e(route('admin.users.delivery-man.status',[$dm['id'],$dm->status?0:1])); ?>','<?php echo e($dm->status?translate('messages.you_want_to_suspend_this_deliveryman'):translate('messages.you_want_to_unsuspend_this_deliveryman')); ?>')" class="btn font-medium <?php echo e($dm->status?'btn--danger':'btn-success'); ?>">
                            <?php echo e($dm->status?translate('messages.suspend_this_delivery_man'):translate('messages.unsuspend_this_delivery_man')); ?>

                    </a>
                    <?php endif; ?>
                    <div class="hs-unfold">
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                    id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                <?php echo e(translate('messages.type')); ?> (<?php echo e($dm->earning?translate('messages.freelancer'):translate('messages.salary_based')); ?>)
                            </button>
                            <div class="dropdown-menu text-capitalize" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item <?php echo e($dm->earning?'active':''); ?>"
                                onclick="request_alert('<?php echo e(route('admin.users.delivery-man.earning',[$dm['id'],1])); ?>','<?php echo e(translate('messages.want_to_enable_earnings')); ?>')"
                                    href="javascript:"><?php echo e(translate('messages.freelancer')); ?></a>
                                <a class="dropdown-item <?php echo e($dm->earning?'':'active'); ?>"
                                onclick="request_alert('<?php echo e(route('admin.users.delivery-man.earning',[$dm['id'],0])); ?>','<?php echo e(translate('messages.want_to_disable_earnings')); ?>')"
                                    href="javascript:"><?php echo e(translate('messages.salary_based')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Body -->
            <div class="card-body">
                <div class="row gy-3 align-items-center">
                    <div class="col-md-4">

                        <h2 class="title"><?php echo e(translate('Vehicle Information')); ?></h2>
                            <?php if(isset($dm->vehicle)): ?>
                            <div><?php echo e(translate('Vehicle_Type')); ?> : <?php echo e($dm->vehicle->type); ?></div>
                            <div><?php echo e(translate('Vehicle_Extra_Charges')); ?> : <?php echo e($dm->vehicle->extra_charges); ?></div>
                            <div><?php echo e(translate('Vehicle_minimum_coverage_area')); ?> : <?php echo e($dm->vehicle->starting_coverage_area); ?></div>
                            <div><?php echo e(translate('Vehicle_maximum_coverage_area')); ?> : <?php echo e($dm->vehicle->maximum_coverage_area); ?></div>
                            <?php else: ?>
                            <div><?php echo e(translate('No_vehicle_data_found')); ?></div>
                            <?php endif; ?>

                    </div>
                    <div class="col-md-4">
                        <div class="d-flex align-items-center justify-content-center">
                            <img class="avatar avatar-xxl avatar-4by3 mr-4 img--120"
                                 onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                 src="<?php echo e(asset('storage/app/public/delivery-man')); ?>/<?php echo e($dm['image']); ?>"
                                 alt="Image Description">





















































































                        </div>
                    </div>














































































                </div>
            </div>
            <!-- End Body -->
        </div>

        <div class="card mb-3">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="tio-user"></i>
                    <span><?php echo e(translate('Identity Documents')); ?></span>
                </h5>
            </div>
            <div class="card-body">
                <div class="pl-3"><span class="te"><?php echo e(translate('Identity_Type')); ?></span> : <?php echo e(translate($dm->identity_type)); ?></div>
                <div class="pl-3"><span class="te"><?php echo e(translate('messages.identification_number')); ?></span> : <?php echo e($dm->identity_number); ?></div>
                <div class="row g-3">
                    <?php $__currentLoopData = json_decode($dm->identity_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-auto">
                                <button class="btn w-100" data-toggle="modal"
                                    data-target="#image-<?php echo e($key); ?>">
                                    <div class="gallary-card">
                                        <img onerror="this.src='<?php echo e(asset('/public/assets/admin/img/900x400/img1.jpg')); ?>'"
                                        src="<?php echo e(asset('storage/app/public/delivery-man')); ?>/<?php echo e($img); ?>" class="w-100">
                                    </div>
                                </button>
                                <div class="modal fade" id="image-<?php echo e($key); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="myModlabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title" id="myModlabel">
                                                <?php echo e(translate('messages.Identity_Image')); ?></h4>
                                            <button type="button" class="close" data-dismiss="modal"><span
                                                    aria-hidden="true">&times;</span><span
                                                    class="sr-only"><?php echo e(translate('messages.Close')); ?></span></button>
                                        </div>
                                        <div class="modal-body">
                                            <img onerror="this.src='<?php echo e(asset('/public/assets/admin/img/900x400/img1.jpg')); ?>'"
                                                src="<?php echo e(asset('storage/app/public/delivery-man/' . $img)); ?>"
                                                class="w-100">
                                        </div>
                                        <div class="modal-footer">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>















































































































































    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
<script>
    function request_alert(url, message) {
        Swal.fire({
            title: '<?php echo e(translate('messages.are_you_sure')); ?>',
            text: message,
            type: 'warning',
            showCancelButton: true,
            cancelButtonColor: 'default',
            confirmButtonColor: '#FC6A57',
            cancelButtonText: '<?php echo e(translate('messages.no')); ?>',
            confirmButtonText: '<?php echo e(translate('messages.yes')); ?>',
            reverseButtons: true
        }).then((result) => {
            if (result.value) {
                location.href = url;
            }
        })
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/happy9/snow-delivery-admin-panel/resources/views/admin-views/delivery-man/view/info.blade.php ENDPATH**/ ?>